       
    <!-- Style -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- Responsive -->
    <link href="css/responsive.css" rel="stylesheet">
    <!-- Choose Layout -->
    <link href="css/layout-semiboxed.css" rel="stylesheet">
    <!-- Choose Skin -->
    <link href="css/skin-red.css" rel="stylesheet">
    <!-- Demo -->
    <link rel="stylesheet" id="main-color" href="css/skin-red.css" media="screen"/>
    <!-- Favicon -->
    <link rel="shortcut icon" href="img/favicon.png">

	<link rel='stylesheet' href='css/simplelightbox.min.css' >
	<link rel="stylesheet" href="css/main.css">
